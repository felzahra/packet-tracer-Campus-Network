At start fastforward 3 to 4 times 
then at desktop of all  pcs check that ip is assign using DHCP
